import { PrismaClient, Role, ChangeType } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  const adminPass = await bcrypt.hash('admin123', 10)
  const admin = await prisma.user.upsert({
    where: { email: 'admin@taj.local' },
    update: {},
    create: { email: 'admin@taj.local', name: 'Admin', role: 'ADMIN', passwordHash: adminPass }
  })

  const companiesData = [
    { nameEn: 'Ocean Pharmaceutical', nameAr: 'أوشن فارما', brandColor: '#0B6BFF' },
    { nameEn: 'HOF Pharma', nameAr: 'هوف فارما', brandColor: '#0B8D6B' },
    { nameEn: 'Shree Venkatesh', nameAr: 'شري فينكاتيش', brandColor: '#8B5CF6' },
    { nameEn: 'Associated Biotech', nameAr: 'أسوشييتد بيوتِك', brandColor: '#FF6B6B' },
    { nameEn: 'Alborz Darou', nameAr: 'البرز دارو', brandColor: '#EAB308' },
    { nameEn: 'Sobhan Darou', nameAr: 'صُبحان دارو', brandColor: '#0891B2' },
  ]

  for (const c of companiesData) {
    await prisma.company.create({ data: { ...c, logoUrl: `/images/companies/${c.nameEn.replace(/\s+/g,'-').toLowerCase()}.svg` } })
  }

  const companies = await prisma.company.findMany()

  const baseProducts = [
    { nameEn: 'Tranixa 500', nameAr: 'ترانيكسا 500', scientificEn: 'Tranexamic Acid', scientificAr: 'حمض الترانيكساميك', pack: '10 tablets', price: '$8.00', indicationsEn: 'Control of bleeding; dental procedures on anticoagulants; menorrhagia.', dosageEn: 'As directed by physician.', notesEn: 'Consult the product insert.' },
    { nameEn: 'Vomi Cure', nameAr: 'فومي كيور', scientificEn: 'Ondansetron', scientificAr: 'أوندانسيترون', pack: '10 tablets', price: '$9.50', indicationsEn: 'Nausea control; post-operative.', dosageEn: 'As directed by physician.', notesEn: 'Use under medical supervision.' },
    { nameEn: 'Ciprotech 500', nameAr: 'سيبروتيك 500', scientificEn: 'Ciprofloxacin', scientificAr: 'سيبروفلوكساسين', pack: '10 tablets', price: '$11.00', indicationsEn: 'Bacterial infections.', dosageEn: 'As directed by physician.', notesEn: 'Follow antibiotic stewardship.' },
    { nameEn: 'Cetrizine HCl', nameAr: 'سيتريزين', scientificEn: 'Cetirizine Hydrochloride', scientificAr: 'سيتريزين هيدروكلورايد', pack: '10 tablets', price: '$7.25', indicationsEn: 'Allergic rhinitis.', dosageEn: 'As directed by physician.', notesEn: 'May cause drowsiness.' },
    { nameEn: 'Cold Cure 325', nameAr: 'كولد كيور 325', scientificEn: 'Paracetamol + Decongestant', scientificAr: 'باراسيتامول + مزيل احتقان', pack: '12 caplets', price: '$6.80', indicationsEn: 'Cold symptoms.', dosageEn: 'As directed by physician.', notesEn: 'Decongestant caution.' },
    { nameEn: 'Colchicine 0.5', nameAr: 'كولشيسين 0.5', scientificEn: 'Colchicine', scientificAr: 'كولشيسين', pack: '10 tablets', price: '$12.30', indicationsEn: 'Gout management.', dosageEn: 'As directed by physician.', notesEn: 'Monitor for GI upset.' },
    { nameEn: 'Cyprotech 4', nameAr: 'سيبروتيك 4', scientificEn: 'Cyproheptadine', scientificAr: 'سيبروهيبتادين', pack: '10 tablets', price: '$5.90', indicationsEn: 'Appetite stimulation.', dosageEn: 'As directed by physician.', notesEn: 'May cause drowsiness.' },
    { nameEn: 'DColax', nameAr: 'ديكولاكس', scientificEn: 'Sodium Picosulfate', scientificAr: 'صوديوم بيكوسلفات', pack: '10 tablets', price: '$4.70', indicationsEn: 'Constipation relief.', dosageEn: 'As directed by physician.', notesEn: 'Hydration recommended.' },
    { nameEn: 'Spasmo Cure', nameAr: 'سبازمو كيور', scientificEn: 'Dicyclomine', scientificAr: 'دايسايكلومين', pack: '10 tablets', price: '$10.10', indicationsEn: 'GI spasms.', dosageEn: 'As directed by physician.', notesEn: 'For short-term relief.' },
  ]

  for (const comp of companies) {
    for (const p of baseProducts) {
      const product = await prisma.product.create({
        data: { ...p, companyId: comp.id, imageUrl: `/images/products/${p.nameEn.replace(/\s+/g,'-').toLowerCase()}.svg` }
      })
      await prisma.change.create({
        data: {
          type: Math.random() > 0.5 ? ChangeType.ADDED : ChangeType.UPDATED,
          productId: product.id,
          userId: admin.id,
          note: Math.random() > 0.5 ? 'New SKU introduced' : 'Revised dosage guidance and price'
        }
      })
    }
    await prisma.company.update({
      where: { id: comp.id },
      data: { productCount: baseProducts.length }
    })
  }
}

main().catch(e => {
  console.error(e)
  process.exit(1)
}).finally(async () => {
  await prisma.$disconnect()
})
