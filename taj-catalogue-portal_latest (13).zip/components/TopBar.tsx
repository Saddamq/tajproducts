'use client'
import { Globe, Download } from 'lucide-react'
import { useState } from 'react'

export default function TopBar() {
  const [locale, setLocale] = useState<'en'|'ar'>('en')
  const rtl = locale === 'ar'
  return (
    <header className="sticky top-0 z-20 bg-white/80 backdrop-blur border-b border-zinc-200" dir={rtl ? 'rtl':'ltr'}>
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600" />
          <div className="font-semibold">{rtl ? 'كتالوج تاج' : 'Taj Catalogue'}</div>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <button
            aria-label="Toggle language"
            onClick={() => setLocale(l => l === 'en' ? 'ar' : 'en')}
            className="flex items-center gap-2 text-sm px-3 py-1.5 rounded-xl border border-zinc-300"
          >
            <Globe className="w-4 h-4" /> {rtl ? 'AR':'EN'}
          </button>
          <a href="/catalogue.pdf" className="flex items-center gap-2 text-sm px-3 py-1.5 rounded-xl bg-zinc-900 text-white hover:bg-zinc-800">
            <Download className="w-4 h-4" /> {rtl ? 'تحميل الكتالوج (PDF)' : 'Download Catalogue (PDF)'}
          </a>
        </div>
      </div>
    </header>
  )
}
