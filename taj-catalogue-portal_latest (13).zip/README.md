# Taj Catalogue Portal (Starter, Latest Stack)

- Next.js 15.5.2 + Tailwind CSS 4 + Prisma (SQLite) + NextAuth v5 (beta) + tsx
- Mockup-accurate UI, elder-friendly
- Central Catalogue PDF link
- Changelog on Home (from DB changes)
- Admin panel for Companies & Products

## Quick start

```bash
# 1) Install deps
pnpm i   # or: npm i / yarn

# 2) Create DB and generate client
pnpm prisma:push

# 3) Seed data (admin user + demo content)
pnpm seed

# 4) Run
pnpm dev
```

**Sign in** at `/signin`  
- Email: `admin@taj.local`  
- Password: `admin123`
