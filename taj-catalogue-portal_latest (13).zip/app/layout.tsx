import "./globals.css"
import TopBar from "@/components/TopBar"
import { ReactNode } from "react"

export const metadata = {
  title: "Taj Catalogue",
  description: "Always-up-to-date product catalogue"
}

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <TopBar />
        {children}
      </body>
    </html>
  )
}
