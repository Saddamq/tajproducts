import { prisma } from "@/lib/prisma"
import Link from "next/link"

export default async function CompanyPage({ params, searchParams }: { params: Promise<{ id: string }>, searchParams: Promise<{ page?: string }> }) {
  const { id } = await params
  const { page = "1" } = await searchParams
  const pageNum = Math.max(1, parseInt(page || "1"))
  const pageSize = 9
  const [company, total] = await Promise.all([
    prisma.company.findUnique({ where: { id } }),
    prisma.product.count({ where: { companyId: id } })
  ])
  if (!company) return <div className="max-w-4xl mx-auto p-6">Company not found.</div>
  const products = await prisma.product.findMany({
    where: { companyId: company.id },
    orderBy: { nameEn: 'asc' },
    take: pageSize,
    skip: (pageNum - 1) * pageSize
  })
  const pages = Math.max(1, Math.ceil(total / pageSize))
  const card = "rounded-2xl shadow-lg border border-zinc-200/60 bg-white/90 backdrop-blur p-4"
  const makeHref = (p: number) => `/companies/${id}?page=${p}`
  return (
    <main className="max-w-6xl mx-auto px-4 pb-16">
      <nav className="text-sm text-zinc-600 mt-4 mb-3">
        <Link href="/" className="hover:underline">Home</Link> &gt; <span>{company.nameEn}</span>
      </nav>
      <div className="flex items-center gap-3 mb-3">
        <img src={company.logoUrl || `/images/companies/${company.nameEn.replace(/\s+/g,'-').toLowerCase()}.svg`} alt="logo" className="w-8 h-8 rounded-lg object-cover" />
        <div>
          <div className="text-sm text-zinc-500">Company</div>
          <div className="font-semibold -mt-1">{company.nameEn}</div>
        </div>
      </div>
      <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
        {products.map(p => (
          <div key={p.id} className={card + " h-36"}>
            <div className="flex items-start gap-3">
              <img src={p.imageUrl || `/images/products/${p.nameEn.replace(/\s+/g,'-').toLowerCase()}.svg`} alt="product" className="w-14 h-14 rounded-xl object-cover" />
              <div className="flex-1">
                <div className="font-medium truncate" title={p.nameEn}>{p.nameEn}</div>
                <div className="text-sm text-zinc-600 truncate" title={p.scientificEn}>{p.scientificEn}</div>
                <div className="text-xs text-zinc-500">{p.pack} · {p.price}</div>
                <div className="mt-3 flex gap-2">
                  <Link href={`/products/${p.id}`} className="text-sm px-3 py-1.5 rounded-xl bg-zinc-900 text-white">View</Link>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      {/* Pagination */}
      <div className="flex items-center justify-center gap-2 mt-6">
        <Link href={makeHref(Math.max(1, pageNum-1))} className={`px-3 py-1.5 rounded-xl border ${pageNum===1?'pointer-events-none opacity-50':'hover:bg-zinc-50'}`}>Prev</Link>
        <span className="text-sm px-3 py-1.5 rounded-xl border bg-white">{pageNum} / {pages}</span>
        <Link href={makeHref(Math.min(pages, pageNum+1))} className={`px-3 py-1.5 rounded-xl border ${pageNum===pages?'pointer-events-none opacity-50':'hover:bg-zinc-50'}`}>Next</Link>
      </div>
    </main>
  )
}
