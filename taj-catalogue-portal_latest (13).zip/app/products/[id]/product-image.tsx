'use client'
import { useState } from 'react'

export default function ProductImage({ src, alt }: { src: string, alt: string }) {
  const [open, setOpen] = useState(false)
  return (
    <>
      <img
        src={src}
        alt={alt}
        onClick={()=>setOpen(true)}
        className="w-24 h-24 rounded-2xl object-cover cursor-zoom-in"
      />
      {open && (
        <div
          className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4"
          onClick={()=>setOpen(false)}
        >
          <img
            src={src}
            alt={alt}
            className="max-w-full max-h-full rounded-2xl shadow-2xl cursor-zoom-out"
            onClick={(e)=>{ e.stopPropagation(); setOpen(false)}}
          />
        </div>
      )}
    </>
  )
}
