import { prisma } from "@/lib/prisma"
import Link from "next/link"
import ProductImage from "./product-image"

export default async function ProductPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const product = await prisma.product.findUnique({ where: { id }, include: { company: true } })
  if (!product) return <div className="max-w-4xl mx-auto p-6">Product not found.</div>
  const card = "rounded-2xl shadow-lg border border-zinc-200/60 bg-white/90 backdrop-blur p-4"
  return (
    <main className="max-w-6xl mx-auto px-4 pb-16">
      <nav className="text-sm text-zinc-600 mt-4 mb-3">
        <Link href="/" className="hover:underline">Home</Link> &gt;{" "}
        <Link href={`/companies/${product.companyId}`} className="hover:underline">{product.company.nameEn}</Link> &gt;{" "}
        <span>{product.nameEn}</span>
      </nav>
      <div className="grid md:grid-cols-3 gap-4 mt-2">
        <div className={card + " md:col-span-2"}>
          <div className="flex items-start gap-4">
            <ProductImage src={product.imageUrl || `/images/products/${product.nameEn.replace(/\s+/g,'-').toLowerCase()}.svg`} alt={product.nameEn} />
            <div>
              <div className="text-2xl font-semibold">{product.nameEn}</div>
              <div className="text-zinc-600">{product.scientificEn} · {product.pack}</div>
            </div>
          </div>
          <div className="mt-6 grid md:grid-cols-2 gap-4 text-sm text-zinc-700">
            <div className={"rounded-xl border border-zinc-200 p-3"}>
              <div className="font-medium">Indications</div>
              <p className="mt-1 whitespace-pre-wrap">{product.indicationsEn || "—"}</p>
            </div>
            <div className={"rounded-xl border border-zinc-200 p-3"}>
              <div className="font-medium">Dosage</div>
              <p className="mt-1 whitespace-pre-wrap">{product.dosageEn || "—"}</p>
            </div>
            <div className={"rounded-xl border border-zinc-200 p-3 md:col-span-2"}>
              <div className="font-medium">Notes</div>
              <p className="mt-1 whitespace-pre-wrap">{product.notesEn || "—"}</p>
            </div>
          </div>
        </div>
        <div className={card}>
          <div className="font-medium">Product Info</div>
          <div className="mt-3 text-sm text-zinc-600 space-y-1">
            <div><span className="text-zinc-500">Price:</span> {product.price}</div>
            <div><span className="text-zinc-500">Company:</span> {product.company.nameEn}</div>
          </div>
        </div>
      </div>
    </main>
  )
}
