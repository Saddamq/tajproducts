'use client'
import { motion, MotionConfig } from 'framer-motion'
import { Search, ChevronRight, Clock, Info } from 'lucide-react'
import Link from 'next/link'
import { useState } from 'react'

type Company = { id: string; nameEn: string; nameAr: string; brandColor: string; productCount: number; logoUrl?: string }
type Change = {
  id: string;
  date: string;
  type: 'ADDED'|'UPDATED';
  note: string;
  product: { nameEn: string; company: { nameEn: string } }
}

export default function HomeClient({ companies, changes }: { companies: Company[]; changes: Change[] }) {
  const [rtl, setRtl] = useState(false)
  const dir = rtl ? 'rtl':'ltr'
  const card = "rounded-2xl shadow-lg border border-zinc-200/60 bg-white/90 backdrop-blur p-4"
  const chip = "px-3 py-1 rounded-full text-xs font-medium bg-zinc-100 border border-zinc-200"

  return (
    <MotionConfig reducedMotion="user">
      <main className="max-w-6xl mx-auto px-4 pb-16" dir={dir}>
        <div className="mt-4 mb-2 text-right">
          <button onClick={()=>setRtl(v=>!v)} className="text-xs underline">{rtl ? 'LTR':'RTL'}</button>
        </div>
        <motion.section initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="grid md:grid-cols-3 gap-4">
          <div className={card + " md:col-span-2 p-6"}>
            <h1 className="text-2xl font-semibold">{rtl ? "كتالوج المنتجات دائم التحديث":"Always‑Up‑to‑Date Product Catalogue"}</h1>
            <p className="mt-2 text-zinc-600">{rtl ? "رابط واحد للفريق، أزرار كبيرة، عربي وإنكليزي.":"One link for your teams. Big buttons. Arabic & English."}</p>
            <div className="mt-4 flex gap-2 flex-wrap">
              <span className={chip}>{rtl ? "ملف PDF مركزي":"Central PDF"}</span>
              <span className={chip}>{rtl ? "مشاركة QR":"QR Share"}</span>
              <span className={chip}>{rtl ? "شركة ← منتجات":"Company → Products"}</span>
              <span className={chip}>{rtl ? "بحث":"Search"}</span>
              <span className={chip}>{rtl ? "أزرار كبيرة":"Large Touch Targets"}</span>
            </div>
            <div className="mt-5">
              <a href="/catalogue.pdf" className="inline-flex items-center gap-2 text-sm px-4 py-2 rounded-xl bg-zinc-900 text-white hover:bg-zinc-800">
                {rtl ? "تحميل أحدث كتالوج (PDF)":"Download Latest Catalogue (PDF)"}
              </a>
            </div>
          </div>

          <div className={card}>
            <div className="flex items-center gap-2 text-sm text-zinc-600"><Search className="w-4 h-4" />{rtl ? "بحث سريع":"Quick Search"}</div>
            <div className="mt-3">
              <input className="w-full px-3 py-2 rounded-xl border border-zinc-300 focus:outline-none" placeholder={rtl ? "ابحث عن المنتجات أو الشركات":"Search products or companies"} />
            </div>
            <div className="mt-3 text-xs text-zinc-500 flex items-center gap-1">
              <Info className="w-3.5 h-3.5" />
              {rtl ? "يمكنك الكتابة بالعربي أو الإنكليزي؛ الواجهة تنعكس تلقائياً.":"Type Arabic or English; the UI flips to RTL automatically."}
            </div>
          </div>

          <div className={card + " md:col-span-3"}>
            <h2 className="font-medium">{rtl ? "الشركات":"Companies"}</h2>
            <div className="mt-3 grid grid-cols-2 md:grid-cols-6 gap-3">
              {companies.map(c => (
                <Link key={c.id} href={`/companies/${c.id}`} className="group">
                  <div className="rounded-2xl border border-zinc-200 p-4 bg-white hover:shadow-md transition text-left h-40 flex flex-col justify-between">
                    <div className="flex items-center gap-3">
                      <img src={c.logoUrl || `/images/companies/${(c.nameEn||"").replace(/\s+/g, "-").toLowerCase()}.svg`} alt="logo" className="w-14 h-14 rounded-xl object-cover"/>
                      <div className="font-medium text-sm whitespace-normal break-words leading-tight">{rtl ? c.nameAr : c.nameEn}</div>
                    </div>
                    <div className="text-xs text-zinc-500 group-hover:text-zinc-700 flex items-center gap-1">
                      {rtl ? "عرض المنتجات":"View products"} <ChevronRight className="w-3 h-3" />
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>

          <div className={card + " md:col-span-3"}>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-zinc-600" />
              <h2 className="font-medium">{rtl ? "آخر التغييرات":"Recent changes"}</h2>
            </div>
            <ul className="mt-3 divide-y divide-zinc-200">
              {changes.map(c => (
                <li key={c.id} className="py-3 flex items-start gap-3">
                  <span className={`text-[10px] px-2 py-1 rounded-full border ${c.type==='ADDED'?'bg-green-100 text-green-700 border-green-200':'bg-amber-100 text-amber-700 border-amber-200'} shrink-0 mt-0.5`}>
                    {c.type==='ADDED' ? (rtl ? "إضافة":"Added") : (rtl ? "تعديل":"Updated")}
                  </span>
                  <div className="flex-1">
                    <div className="text-sm font-medium">{c.product.nameEn} <span className="text-zinc-500 font-normal">· {c.product.company.nameEn}</span></div>
                    <div className="text-xs text-zinc-600">{c.note}</div>
                  </div>
                  <div className="text-xs text-zinc-500 shrink-0">{new Date(c.date).toISOString().slice(0,10)}</div>
                </li>
              ))}
            </ul>
          </div>
        </motion.section>
      </main>
    </MotionConfig>
  )
}
