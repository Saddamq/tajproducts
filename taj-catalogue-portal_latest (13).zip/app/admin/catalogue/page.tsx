import { prisma } from "@/lib/prisma"
import CatalogueClient from "./ui/CatalogueClient"

export default async function CataloguePage() {
  const companies = await prisma.company.findMany({ orderBy: { nameEn: 'asc' } })
  return <CatalogueClient companies={companies} />
}
