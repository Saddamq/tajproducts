'use client'
import { useState } from 'react'

type Company = { id: string; nameEn: string; logoUrl?: string | null }

export default function CatalogueClient({ companies }: { companies: Company[] }) {
  const [items, setItems] = useState(companies.map(c => ({ ...c, include: true })))
  const [status, setStatus] = useState('')

  function toggle(id: string) {
    setItems(prev => prev.map(i => i.id===id ? { ...i, include: !i.include } : i))
  }
  function move(id: string, dir: -1 | 1) {
    setItems(prev => {
      const idx = prev.findIndex(i => i.id===id)
      if (idx < 0) return prev
      const j = idx + dir
      if (j < 0 || j >= prev.length) return prev
      const copy = [...prev]
      const [x] = copy.splice(idx,1)
      copy.splice(j,0,x)
      return copy
    })
  }

  async function generate() {
    setStatus('Generating...')
    const selected = items.filter(i=>i.include).map(i => i.id)
    const res = await fetch('/api/admin/generate-pdf', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ companyIds: selected })
    })
    if (!res.ok) {
      setStatus('Failed')
      return
    }
    const blob = await res.blob()
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = 'catalogue.pdf'; a.click()
    setStatus('Done. Also saved as /public/catalogue.pdf')
  }

  const card = "rounded-2xl border p-3 bg-white flex items-center justify-between"

  return (
    <main className="max-w-3xl mx-auto p-4">
      <h1 className="text-xl font-semibold mb-2">Generate Catalogue PDF</h1>
      <p className="text-sm text-zinc-600 mb-4">Select companies to include and arrange their order. Layout: 2 columns × 3 rows per page (6 products). Each company starts on a new page, with logo in header.</p>
      <div className="grid gap-2">
        {items.map((c, idx) => (
          <div key={c.id} className={card}>
            <div className="flex items-center gap-3">
              <input type="checkbox" checked={c.include} onChange={()=>toggle(c.id)} />
              <img src={c.logoUrl || `/images/companies/${c.nameEn.replace(/\s+/g,'-').toLowerCase()}.svg`} className="w-8 h-8 rounded-md object-cover" alt="" />
              <div className="font-medium">{c.nameEn}</div>
            </div>
            <div className="flex items-center gap-2">
              <button className="px-2 py-1 rounded-lg border" onClick={()=>move(c.id, -1)} disabled={idx===0}>↑</button>
              <button className="px-2 py-1 rounded-lg border" onClick={()=>move(c.id, 1)} disabled={idx===items.length-1}>↓</button>
            </div>
          </div>
        ))}
      </div>
      <button onClick={generate} className="mt-4 px-4 py-2 rounded-xl bg-zinc-900 text-white">Generate PDF</button>
      <div className="mt-3 text-sm text-zinc-600">{status}</div>
    </main>
  )
}
