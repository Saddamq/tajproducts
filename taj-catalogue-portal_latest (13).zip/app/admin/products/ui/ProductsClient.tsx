'use client'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import Toast from '@/app/components/Toast'

const schema = z.object({
  companyId: z.string().min(1),
  nameEn: z.string().min(2),
  
  scientificEn: z.string().min(2),
  
  pack: z.string().min(1),
  price: z.string().min(1),
  imageUrl: z.string().optional(), indicationsEn: z.string().optional(), dosageEn: z.string().optional(), notesEn: z.string().optional()
})
type ProductForm = z.infer<typeof schema> & { indicationsEn?: string; dosageEn?: string; notesEn?: string }

async function uploadFile(file: File): Promise<string> {
  const fd = new FormData()
  fd.append('file', file)
  const res = await fetch('/api/upload', { method: 'POST', body: fd })
  const json = await res.json()
  return json.url
}

export default function ProductsClient({ companies, products }: { companies: any[]; products: any[] }) {
  const router = useRouter()
  const f = useForm<ProductForm>({ resolver: zodResolver(schema) })
      const [err, setErr] = useState<string>('')
      const [editErr, setEditErr] = useState<string>('')
      const [toast, setToast] = useState<{msg:string,type:'success'|'error'}|null>(null)
  const [editId, setEditId] = useState<string|null>(null)
  const ef = useForm<ProductForm>({ resolver: zodResolver(schema) })

  async function createProduct(data: ProductForm) {
        setErr('')
    const res = await fetch('/api/admin/product', { method: 'POST', body: JSON.stringify(data) });
        if (!res.ok) { const j = await res.json().catch(()=>({error:'Failed'})); setErr(j.error || 'Failed to create product'); return }
    f.reset()
    setToast({ msg: 'Product deleted', type: 'success' })
        router.refresh()
  }
  async function del(id: string) {
        if (!confirm('Delete this product?')) return;
    await fetch('/api/admin/product?id='+id, { method: 'DELETE' })
    router.refresh()
  }
  function startEdit(p: any) {
    setEditId(p.id)
    ef.reset({ companyId: p.companyId, nameEn: p.nameEn,  scientificEn: p.scientificEn,  pack: p.pack, price: p.price, imageUrl: p.imageUrl || '' })
  }
  async function saveEdit(data: any) {
        setEditErr('')
    const res = await fetch('/api/admin/product', { method: 'PATCH', body: JSON.stringify({ id: editId, ...data }) });
        if (!res.ok) { const j = await res.json().catch(()=>({error:'Failed'})); setEditErr(j.error || 'Failed to update product'); return }
    setEditId(null); setToast({ msg: 'Product updated', type: 'success' }); router.refresh()
  }

  const card = "rounded-2xl shadow-lg border border-zinc-200/60 bg-white/90 backdrop-blur p-4"
  return (
    <div>
      <h1 className="text-xl font-semibold mb-4">Products</h1>
      <div className="grid md:grid-cols-3 gap-4">
        <div className={card}>
          <div className="font-medium mb-2">Create product</div>
          {err && <div className="text-sm text-red-600 mb-2">{err}</div>}
              <form className="grid gap-2" onSubmit={f.handleSubmit(createProduct)}>
            <select className="px-3 py-2 rounded-xl border" {...f.register('companyId')}>
              <option value="">Select company</option>
              {companies.map(c => <option key={c.id} value={c.id}>{c.nameEn}</option>)}
            </select>
            <input placeholder="Name (EN)" className="px-3 py-2 rounded-xl border" {...f.register('nameEn')} />
                       <input placeholder="Scientific (EN)" className="px-3 py-2 rounded-xl border" {...f.register('scientificEn')} />
                       <input placeholder="Pack" className="px-3 py-2 rounded-xl border" {...f.register('pack')} />
            <input placeholder="Price" className="px-3 py-2 rounded-xl border" {...f.register('price')} />
            <div className="grid gap-2">
              <input placeholder="Image URL (optional)" className="px-3 py-2 rounded-xl border" {...f.register('imageUrl')} />
              <input type="file" accept="image/*" onChange={async (e)=>{
                const file = e.target.files?.[0]; if (!file) return;
                const url = await uploadFile(file); f.setValue('imageUrl', url);
              }}/>
            </div>
            <button className="px-3 py-2 rounded-xl bg-zinc-900 text-white">Create</button>
          </form>
        </div>
        <div className={card + " md:col-span-2"}>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
            {products.map(p => (
              <div key={p.id} className="rounded-2xl border p-3 bg-white">
                <div className="flex items-center gap-2">
                  <img src={p.imageUrl || `/images/products/${p.nameEn.replace(/\s+/g,'-').toLowerCase()}.svg`} alt="prod" className="w-8 h-8 rounded-md object-cover" />
                  <div className="font-medium">{p.nameEn}</div>
                </div>
                <div className="mt-2 text-xs text-zinc-600">{p.scientificEn}</div>
                <div className="text-xs text-zinc-500">{p.pack} · {p.price}</div>
                <div className="flex gap-3 mt-2 text-xs">
                  <button onClick={()=>startEdit(p)} className="underline">Edit</button>
                  <button onClick={()=>del(p.id)} className="underline text-red-600">Delete</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {editId && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={()=>setEditId(null)}>
          <div className="bg-white rounded-2xl p-4 w-full max-w-lg" onClick={e=>e.stopPropagation()}>
            <div className="font-medium mb-2">Edit product</div>
            {editErr && <div className="text-sm text-red-600 mb-2">{editErr}</div>}
                <form className="grid gap-2" onSubmit={ef.handleSubmit(saveEdit)}>
              <select className="px-3 py-2 rounded-xl border" {...ef.register('companyId')}>
                {companies.map(c => <option key={c.id} value={c.id}>{c.nameEn}</option>)}
              </select>
              <input placeholder="Name (EN)" className="px-3 py-2 rounded-xl border" {...ef.register('nameEn')} />
              <input placeholder="Name (AR)" className="px-3 py-2 rounded-xl border" {...ef.register('nameAr')} />
              <input placeholder="Scientific (EN)" className="px-3 py-2 rounded-xl border" {...ef.register('scientificEn')} />
              <input placeholder="Scientific (AR)" className="px-3 py-2 rounded-xl border" {...ef.register('scientificAr')} />
              <input placeholder="Pack" className="px-3 py-2 rounded-xl border" {...ef.register('pack')} />
              <input placeholder="Price" className="px-3 py-2 rounded-xl border" {...ef.register('price')} />
              <div className="grid gap-2">
                <input placeholder="Image URL" className="px-3 py-2 rounded-xl border" {...ef.register('imageUrl')} />
                <input type="file" accept="image/*" onChange={async (e)=>{
                  const file = e.target.files?.[0]; if (!file) return;
                  const url = await uploadFile(file); ef.setValue('imageUrl', url);
                }}/>
              </div>
              <div className="flex justify-end gap-2 mt-2">
                <button type="button" onClick={()=>setEditId(null)} className="px-3 py-2 rounded-xl border">Cancel</button>
                <button className="px-3 py-2 rounded-xl bg-zinc-900 text-white">Save</button>
              </div>
            </form>
          </div>
        </div>
      )}
      {toast && <Toast message={toast.msg} type={toast.type} onClose={()=>setToast(null)} />}
    </div>
  )
}
