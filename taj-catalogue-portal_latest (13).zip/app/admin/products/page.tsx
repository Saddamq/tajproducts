import { prisma } from "@/lib/prisma"
import ProductsClient from "./ui/ProductsClient"

export default async function AdminProductsPage() {
  const companies = await prisma.company.findMany({ orderBy: { nameEn: 'asc' } })
  const products = await prisma.product.findMany({ orderBy: { nameEn: 'asc' } })
  return <ProductsClient companies={companies} products={products} />
}
