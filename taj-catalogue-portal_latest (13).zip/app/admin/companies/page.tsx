import { prisma } from "@/lib/prisma"
import CompaniesClient from "./ui/CompaniesClient"

export default async function AdminCompaniesPage() {
  const companies = await prisma.company.findMany({ orderBy: { nameEn: 'asc' } })
  return <CompaniesClient companies={companies} />
}
