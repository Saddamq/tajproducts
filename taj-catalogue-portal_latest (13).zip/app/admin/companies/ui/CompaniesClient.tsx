'use client'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import Toast from '@/app/components/Toast'

const schema = z.object({
  nameEn: z.string().min(2),
  nameAr: z.string().min(2),
  brandColor: z.string().min(4),
  logoUrl: z.string().optional()
})
type CompanyForm = z.infer<typeof schema>

async function uploadFile(file: File): Promise<string> {
  const fd = new FormData()
  fd.append('file', file)
  const res = await fetch('/api/upload', { method: 'POST', body: fd })
  const json = await res.json()
  return json.url
}

export default function CompaniesClient({ companies }: { companies: any[] }) {
  const router = useRouter()
  const f = useForm<CompanyForm>({ resolver: zodResolver(schema) })
  const [editId, setEditId] = useState<string|null>(null)
  const ef = useForm<CompanyForm>({ resolver: zodResolver(schema) })

  async function createCompany(data: CompanyForm) {
    setErr('')
    const res = await fetch('/api/admin/company', { method: 'POST', body: JSON.stringify(data) });
    if (!res.ok) { const j = await res.json().catch(()=>({error:'Failed'})); setErr(j.error || 'Failed to create company'); return }
    f.reset()
    setToast({ msg: 'Company created', type: 'success' })
    setToast({ msg: 'Company deleted', type: 'success' })
    router.refresh()
  }
  async function del(id: string) {
    if (!confirm('Delete this company and all of its products?')) return;
    await fetch('/api/admin/company?id='+id, { method: 'DELETE' })
    router.refresh()
  }
  function startEdit(c: any) {
    setEditId(c.id)
    ef.reset({ nameEn: c.nameEn, nameAr: c.nameAr, brandColor: c.brandColor, logoUrl: c.logoUrl || '' })
  }
  async function saveEdit(data: CompanyForm) {
    setEditErr('')
    const res = await fetch('/api/admin/company', { method: 'PATCH', body: JSON.stringify({ id: editId, ...data }) });
    if (!res.ok) { const j = await res.json().catch(()=>({error:'Failed'})); setEditErr(j.error || 'Failed to update company'); return }
    setEditId(null); router.refresh()
  }

  const card = "rounded-2xl shadow-lg border border-zinc-200/60 bg-white/90 backdrop-blur p-4"

  return (
    <div>
      <h1 className="text-xl font-semibold mb-4">Companies</h1>
      <div className="grid md:grid-cols-3 gap-4">
        <div className={card}>
          <div className="font-medium mb-2">Create company</div>
          {err && <div className="text-sm text-red-600 mb-2">{err}</div>}
            <form className="grid gap-2" onSubmit={f.handleSubmit(createCompany)}>
            <input placeholder="Name (EN)" className="px-3 py-2 rounded-xl border" {...f.register('nameEn')} />
            <input placeholder="Name (AR)" className="px-3 py-2 rounded-xl border" {...f.register('nameAr')} />
            <input placeholder="Brand color (e.g. #0B6BFF)" className="px-3 py-2 rounded-xl border" {...f.register('brandColor')} />
            <div className="grid gap-2">
              <input placeholder="Logo URL (optional)" className="px-3 py-2 rounded-xl border" {...f.register('logoUrl')} />
              <input type="file" accept="image/*" onChange={async (e)=>{
                const file = e.target.files?.[0]; if (!file) return;
                const url = await uploadFile(file); f.setValue('logoUrl', url);
              }}/>
            </div>
            <button className="px-3 py-2 rounded-xl bg-zinc-900 text-white">Create</button>
          </form>
        </div>
        <div className={card + " md:col-span-2"}>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
            {companies.map(c => (
              <div key={c.id} className="rounded-2xl border p-3 bg-white">
                <div className="flex items-center gap-2">
                  <img src={c.logoUrl || `/images/companies/${c.nameEn.replace(/\s+/g,'-').toLowerCase()}.svg`} alt="logo" className="w-8 h-8 rounded-md object-cover" />
                  <div className="font-medium">{c.nameEn}</div>
                </div>
                <div className="mt-2 text-xs text-zinc-600">{c.nameAr}</div>
                <div className="flex gap-3 mt-2 text-xs">
                  <button onClick={()=>startEdit(c)} className="underline">Edit</button>
                  <button onClick={()=>del(c.id)} className="underline text-red-600">Delete</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {editId && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={()=>setEditId(null)}>
          <div className="bg-white rounded-2xl p-4 w-full max-w-lg" onClick={e=>e.stopPropagation()}>
            <div className="font-medium mb-2">Edit company</div>
            {editErr && <div className="text-sm text-red-600 mb-2">{editErr}</div>}
                <form className="grid gap-2" onSubmit={ef.handleSubmit(saveEdit)}>
              <input placeholder="Name (EN)" className="px-3 py-2 rounded-xl border" {...ef.register('nameEn')} />
              <input placeholder="Name (AR)" className="px-3 py-2 rounded-xl border" {...ef.register('nameAr')} />
              <input placeholder="Brand color" className="px-3 py-2 rounded-xl border" {...ef.register('brandColor')} />
              <div className="grid gap-2">
                <input placeholder="Logo URL" className="px-3 py-2 rounded-xl border" {...ef.register('logoUrl')} />
                <input type="file" accept="image/*" onChange={async (e)=>{
                  const file = e.target.files?.[0]; if (!file) return;
                  const url = await uploadFile(file); ef.setValue('logoUrl', url);
                }}/>
              </div>
              <div className="flex justify-end gap-2 mt-2">
                <button type="button" onClick={()=>setEditId(null)} className="px-3 py-2 rounded-xl border">Cancel</button>
                <button className="px-3 py-2 rounded-xl bg-zinc-900 text-white">Save</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}