'use client'
import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { useRouter } from 'next/navigation'

const companySchema = z.object({
  nameEn: z.string().min(2),
  nameAr: z.string().min(2),
  brandColor: z.string().min(4)
})
type CompanyForm = z.infer<typeof companySchema>

const productSchema = z.object({
  companyId: z.string().min(1),
  nameEn: z.string().min(2),
  nameAr: z.string().min(2),
  scientificEn: z.string().min(2),
  scientificAr: z.string().min(2),
  pack: z.string().min(1),
  price: z.string().min(1),
})
type ProductForm = z.infer<typeof productSchema>

export default function AdminPanel({ companies, products }: { companies: any[]; products: any[] }) {
  const [tab, setTab] = useState<'companies'|'products'>('companies')
  const router = useRouter()

  const cf = useForm<CompanyForm>({ resolver: zodResolver(companySchema) })
  const pf = useForm<ProductForm>({ resolver: zodResolver(productSchema) })

  async function createCompany(data: CompanyForm) {
    await fetch('/api/admin/company', { method: 'POST', body: JSON.stringify(data) })
    cf.reset()
    router.refresh()
  }
  async function createProduct(data: ProductForm) {
    await fetch('/api/admin/product', { method: 'POST', body: JSON.stringify(data) })
    pf.reset()
    router.refresh()
  }
  async function deleteCompany(id: string) {
    await fetch('/api/admin/company?id=' + id, { method: 'DELETE' })
    router.refresh()
  }
  async function deleteProduct(id: string) {
    await fetch('/api/admin/product?id=' + id, { method: 'DELETE' })
    router.refresh()
  }

  const card = "rounded-2xl shadow-lg border border-zinc-200/60 bg-white/90 backdrop-blur p-4"

  return (
    <main className="max-w-6xl mx-auto px-4 pb-16">
      <div className="flex gap-2 mt-6">
        <button onClick={()=>setTab('companies')} className={`px-3 py-1.5 rounded-xl text-sm border ${tab==='companies'?'bg-zinc-900 text-white border-zinc-900':'bg-white border-zinc-200'}`}>Companies</button>
        <button onClick={()=>setTab('products')} className={`px-3 py-1.5 rounded-xl text-sm border ${tab==='products'?'bg-zinc-900 text-white border-zinc-900':'bg-white border-zinc-200'}`}>Products</button>
      </div>

      {tab==='companies' && (
        <section className="grid md:grid-cols-3 gap-4 mt-4">
          <div className={card}>
            <div className="font-medium mb-2">Create company</div>
            <form className="grid gap-2" onSubmit={cf.handleSubmit(createCompany)}>
              <input placeholder="Name (EN)" className="px-3 py-2 rounded-xl border" {...cf.register('nameEn')} />
              <input placeholder="Name (AR)" className="px-3 py-2 rounded-xl border" {...cf.register('nameAr')} />
              <input placeholder="Brand color (e.g. #0B6BFF)" className="px-3 py-2 rounded-xl border" {...cf.register('brandColor')} />
              <button className="px-3 py-2 rounded-xl bg-zinc-900 text-white">Create</button>
            </form>
          </div>
          <div className={card + " md:col-span-2"}>
            <div className="font-medium mb-2">Companies</div>
            <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
              {companies.map(c => (
                <div key={c.id} className="rounded-2xl border p-3 bg-white">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-md" style={{ background: c.brandColor }} />
                    <div className="font-medium">{c.nameEn}</div>
                  </div>
                  <div className="mt-2 text-xs text-zinc-600">{c.nameAr}</div>
                  <button onClick={()=>deleteCompany(c.id)} className="mt-3 text-xs underline">Delete</button>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {tab==='products' && (
        <section className="grid md:grid-cols-3 gap-4 mt-4">
          <div className={card}>
            <div className="font-medium mb-2">Create product</div>
            <form className="grid gap-2" onSubmit={pf.handleSubmit(createProduct)}>
              <select className="px-3 py-2 rounded-xl border" {...pf.register('companyId')}>
                <option value="">Select company</option>
                {companies.map(c => <option key={c.id} value={c.id}>{c.nameEn}</option>)}
              </select>
              <input placeholder="Name (EN)" className="px-3 py-2 rounded-xl border" {...pf.register('nameEn')} />
              <input placeholder="Name (AR)" className="px-3 py-2 rounded-xl border" {...pf.register('nameAr')} />
              <input placeholder="Scientific (EN)" className="px-3 py-2 rounded-xl border" {...pf.register('scientificEn')} />
              <input placeholder="Scientific (AR)" className="px-3 py-2 rounded-xl border" {...pf.register('scientificAr')} />
              <input placeholder="Pack" className="px-3 py-2 rounded-xl border" {...pf.register('pack')} />
              <input placeholder="Price" className="px-3 py-2 rounded-xl border" {...pf.register('price')} />
              <button className="px-3 py-2 rounded-xl bg-zinc-900 text-white">Create</button>
            </form>
          </div>
          <div className={card + " md:col-span-2"}>
            <div className="font-medium mb-2">Products</div>
            <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
              {products.map(p => (
                <div key={p.id} className="rounded-2xl border p-3 bg-white">
                  <div className="font-medium">{p.nameEn}</div>
                  <div className="text-xs text-zinc-600">{p.scientificEn}</div>
                  <div className="text-xs text-zinc-500">{p.pack} · {p.price}</div>
                  <button onClick={()=>deleteProduct(p.id)} className="mt-3 text-xs underline">Delete</button>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}
    </main>
  )
}
