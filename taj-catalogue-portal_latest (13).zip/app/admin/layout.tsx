import "../globals.css"
import Link from "next/link"
import { ReactNode } from "react"
import { auth } from "@/lib/auth"

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const session = await auth()
  if (!session || (session as any).role !== 'ADMIN') {
    return <div className="max-w-4xl mx-auto p-6">Not authorized. Please sign in as admin.</div>
  }
  return (
    <div className="min-h-screen grid md:grid-cols-[240px_1fr]">
      <aside className="border-r border-zinc-200 bg-white/70 backdrop-blur p-4">
        <div className="font-semibold mb-4">Admin</div>
        <nav className="grid gap-2 text-sm">
          <Link href="/admin/companies" className="px-3 py-2 rounded-xl hover:bg-zinc-100">Companies</Link>
          <Link href="/admin/products" className="px-3 py-2 rounded-xl hover:bg-zinc-100">Products</Link>
          <Link href="/admin/users" className="px-3 py-2 rounded-xl hover:bg-zinc-100">Users</Link>
        </nav>
      </aside>
      <section className="p-4">{children}</section>
    </div>
  )
}
