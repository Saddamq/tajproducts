'use client'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import Toast from '@/app/components/Toast'

const schema = z.object({
  email: z.string().email(),
  name: z.string().optional(),
  password: z.string().min(6),
  role: z.enum(['USER','ADMIN'])
})
type UserForm = z.infer<typeof schema>

export default function UsersClient({ users }: { users: any[] }) {
  const router = useRouter()
  const f = useForm<UserForm>({ resolver: zodResolver(schema), defaultValues: { role: 'USER' } })
  const [err, setErr] = useState<string>('')
  const [toast, setToast] = useState<{msg:string,type:'success'|'error'}|null>(null)

  async function createUser(data: UserForm) {
    setErr('')
    const res = await fetch('/api/admin/user', { method: 'POST', body: JSON.stringify(data) })
    if (!res.ok) {
      const j = await res.json().catch(()=>({error:'Failed'}))
      setErr(j.error || 'Failed to create user')
      return
    }
    f.reset({ role: 'USER' })
    setToast({ msg: 'User created', type: 'success' })
    setToast({ msg: 'User deleted', type: 'success' })
    router.refresh()
  }
  async function del(id: string) {
    if (!confirm('Delete this user?')) return;
    setErr('')
    const res = await fetch('/api/admin/user?id='+id, { method: 'DELETE' })
    if (!res.ok) {
      const j = await res.json().catch(()=>({error:'Failed'}))
      setErr(j.error || 'Failed to delete user')
      return
    }
    router.refresh()
  }

  const card = "rounded-2xl shadow-lg border border-zinc-200/60 bg-white/90 backdrop-blur p-4"
  return (
    <div>
      <h1 className="text-xl font-semibold mb-4">Users</h1>
      <div className="grid md:grid-cols-3 gap-4">
        <div className={card}>
          <div className="font-medium mb-2">Create user</div>
          {err && <div className="text-sm text-red-600 mb-2">{err}</div>}
          <form className="grid gap-2" onSubmit={f.handleSubmit(createUser)}>
            <input placeholder="Email" className="px-3 py-2 rounded-xl border" {...f.register('email')} />
            <input placeholder="Name" className="px-3 py-2 rounded-xl border" {...f.register('name')} />
            <input placeholder="Password" type="password" className="px-3 py-2 rounded-xl border" {...f.register('password')} />
            <select className="px-3 py-2 rounded-xl border" {...f.register('role')}>
              <option value="USER">USER</option>
              <option value="ADMIN">ADMIN</option>
            </select>
            <button className="px-3 py-2 rounded-xl bg-zinc-900 text-white">Create</button>
          </form>
        </div>
        <div className={card + " md:col-span-2"}>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
            {users.map(u => (
              <div key={u.id} className="rounded-2xl border p-3 bg-white">
                <div className="font-medium">{u.email}</div>
                <div className="text-xs text-zinc-600">{u.name || '-'}</div>
                <div className="text-xs text-zinc-500">{u.role}</div>
                <button onClick={()=>del(u.id)} className="mt-3 text-xs underline">Delete</button>
              </div>
            ))}
          </div>
        </div>
      </div>
      {toast && <Toast message={toast.msg} type={toast.type} onClose={()=>setToast(null)} />}
    </div>
  )
}
