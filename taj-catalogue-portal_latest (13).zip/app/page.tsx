import { prisma } from "@/lib/prisma"
import HomeClient from "./ui/HomeClient"

export default async function HomePage() {
  const companies = await prisma.company.findMany({ orderBy: { nameEn: 'asc' } })
  const changes = await prisma.change.findMany({
    orderBy: { date: 'desc' },
    take: 10,
    include: { product: { include: { company: true } } }
  })
  return <HomeClient companies={companies} changes={changes} />
}
