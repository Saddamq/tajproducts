'use client'
import { useState } from 'react'
import { signIn } from 'next-auth/react'
import { useRouter } from 'next/navigation'

export default function SignInPage() {
  const [email, setEmail] = useState('admin@taj.local')
  const [password, setPassword] = useState('admin123')
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    const res = await signIn('credentials', { email, password, redirect: false })
    if ((res as any)?.error) setError('Invalid credentials')
    else router.push('/admin')
  }

  return (
    <main className="max-w-md mx-auto p-6">
      <h1 className="text-2xl font-semibold mb-4">Sign in</h1>
      <form onSubmit={handleSubmit} className="grid gap-3">
        <input className="px-3 py-2 rounded-xl border" value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" />
        <input type="password" className="px-3 py-2 rounded-xl border" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" />
        <button className="px-3 py-2 rounded-xl bg-zinc-900 text-white">Sign in</button>
        {error && <div className="text-sm text-red-600">{error}</div>}
      </form>
    </main>
  )
}
