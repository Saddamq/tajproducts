import { NextRequest } from "next/server"
import { writeFile, mkdir } from "node:fs/promises"
import { join } from "node:path"

export async function POST(req: NextRequest) {
  const form = await req.formData()
  const file = form.get("file")
  if (!(file instanceof File)) {
    return new Response(JSON.stringify({ error: "No file" }), { status: 400 })
  }
  const arrayBuffer = await file.arrayBuffer()
  const buffer = Buffer.from(arrayBuffer)
  const uploadsDir = join(process.cwd(), "public", "uploads")
  await mkdir(uploadsDir, { recursive: true })
  const ext = file.name.split(".").pop() || "bin"
  const filename = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`
  const filepath = join(uploadsDir, filename)
  await writeFile(filepath, buffer)
  const url = `/uploads/${filename}`
  return new Response(JSON.stringify({ url }), { status: 200 })
}
