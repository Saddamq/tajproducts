import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function POST(req: NextRequest) {
  try {
    const data = await req.json()
    const created = await prisma.company.create({ data })
    return NextResponse.json(created)
  } catch (e: any) {
    if (e.code === 'P2002') {
      return NextResponse.json({ error: "Company already exists." }, { status: 409 })
    }
    return NextResponse.json({ error: "Failed to create company." }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const { id, ...data } = await req.json()
    const updated = await prisma.company.update({ where: { id }, data })
    return NextResponse.json(updated)
  } catch (e: any) {
    if (e.code === 'P2002') {
      return NextResponse.json({ error: "Duplicate company data." }, { status: 409 })
    }
    if (e.code === 'P2025') {
      return NextResponse.json({ error: "Company not found." }, { status: 404 })
    }
    return NextResponse.json({ error: "Failed to update company." }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const id = req.nextUrl.searchParams.get('id')
    if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 })
    // Cascade delete: remove product changes, products, then company
    await prisma.$transaction(async (tx) => {
      const productIds = (await tx.product.findMany({ where: { companyId: id }, select: { id: true } })).map(p => p.id)
      if (productIds.length) {
        await tx.change.deleteMany({ where: { productId: { in: productIds } } })
        await tx.product.deleteMany({ where: { id: { in: productIds } } })
      }
      await tx.company.delete({ where: { id } })
    })
    return NextResponse.json({ ok: true })
  } catch (e: any) {
    if (e.code === 'P2025') {
      return NextResponse.json({ error: "Company not found." }, { status: 404 })
    }
    return NextResponse.json({ error: "Failed to delete company." }, { status: 500 })
  }
}
