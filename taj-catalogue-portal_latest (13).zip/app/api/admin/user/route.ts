import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { hash } from "bcryptjs"

export async function POST(req: NextRequest) {
  try {
    const { email, name, password, role } = await req.json()
    const passwordHash = await hash(password, 10)
    const created = await prisma.user.create({ data: { email, name, role, passwordHash } })
    return NextResponse.json(created)
  } catch (e: any) {
    if (e.code === 'P2002') {
      return NextResponse.json({ error: "Email already exists." }, { status: 409 })
    }
    return NextResponse.json({ error: "Failed to create user." }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const id = req.nextUrl.searchParams.get('id')
    if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 })
    await prisma.user.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e: any) {
    if (e.code === 'P2025') {
      return NextResponse.json({ error: "User not found." }, { status: 404 })
    }
    return NextResponse.json({ error: "Failed to delete user." }, { status: 500 })
  }
}
