import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function POST(req: NextRequest) {
  try {
    const data = await req.json()
    const created = await prisma.product.create({ data })
    await prisma.company.update({
      where: { id: data.companyId },
      data: { productCount: { increment: 1 } }
    })
    await prisma.change.create({
      data: { type: 'ADDED', productId: created.id, note: 'Created via admin' }
    })
    return NextResponse.json(created)
  } catch (e: any) {
    if (e.code === 'P2002') {
      return NextResponse.json({ error: "Duplicate product data." }, { status: 409 })
    }
    return NextResponse.json({ error: "Failed to create product." }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const { id, ...data } = await req.json()
    const updated = await prisma.product.update({ where: { id }, data })
    await prisma.change.create({
      data: { type: 'UPDATED', productId: id, note: 'Updated via admin' }
    })
    return NextResponse.json(updated)
  } catch (e: any) {
    if (e.code === 'P2002') {
      return NextResponse.json({ error: "Duplicate product data." }, { status: 409 })
    }
    if (e.code === 'P2025') {
      return NextResponse.json({ error: "Product not found." }, { status: 404 })
    }
    return NextResponse.json({ error: "Failed to update product." }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const id = req.nextUrl.searchParams.get('id')
    if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 })
    await prisma.change.deleteMany({ where: { productId: id } })
    const prod = await prisma.product.delete({ where: { id } })
    await prisma.company.update({
      where: { id: prod.companyId },
      data: { productCount: { decrement: 1 } }
    })
    return NextResponse.json({ ok: true })
  } catch (e: any) {
    if (e.code === 'P2025') {
      return NextResponse.json({ error: "Product not found." }, { status: 404 })
    }
    return NextResponse.json({ error: "Failed to delete product." }, { status: 500 })
  }
}
