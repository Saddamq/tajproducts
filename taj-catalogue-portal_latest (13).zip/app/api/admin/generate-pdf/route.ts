import { prisma } from "@/lib/prisma"
import { NextRequest } from "next/server"
import { PDFDocument, StandardFonts, rgb } from "pdf-lib"
import { join } from "node:path"
import { readFile, writeFile } from "node:fs/promises"

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function POST(req: NextRequest) {
  const body = await req.json().catch(()=>({})) as any
  const companyIds: string[] | undefined = body?.companyIds
  const all = await prisma.company.findMany({ orderBy: { nameEn: 'asc' } })
  const companies = companyIds && companyIds.length ? all.filter(c => companyIds.includes(c.id)) : all
  // preserve requested order if provided
  const orderMap = new Map((companyIds||companies.map(c=>c.id)).map((id, i)=>[id, i]))
  companies.sort((a,b)=> (orderMap.get(a.id)??0) - (orderMap.get(b.id)??0))
  const productsByCompany: Record<string, any[]> = {}
  for (const c of companies) {
    productsByCompany[c.id] = await prisma.product.findMany({ where: { companyId: c.id }, orderBy: { nameEn: 'asc' } })
  }

  const pdf = await PDFDocument.create()
  const font = await pdf.embedFont(StandardFonts.Helvetica)

  const pageSize = { width: 595.28, height: 841.89 } // A4 in points
  const margin = 36

  for (const company of companies) {
    const prods = productsByCompany[company.id]
    let i = 0
    while (i < prods.length || (i === 0 && prods.length === 0)) {
      const page = pdf.addPage([pageSize.width, pageSize.height])

      // Header
      const title = company.nameEn
      const headerY = pageSize.height - margin - 24
      page.drawText(title, { x: margin, y: headerY, size: 18, font, color: rgb(0.07,0.09,0.15) })
      // Logo (optional)
      if (company.logoUrl) {
        try {
          const logoPath = join(process.cwd(), "public", company.logoUrl.replace(/^\//,''))
          const bytes = await readFile(logoPath)
          const ext = logoPath.split('.').pop()?.toLowerCase()
          let img
          if (ext === 'png') img = await pdf.embedPng(bytes)
          else img = await pdf.embedJpg(bytes)
          page.drawImage(img, { x: pageSize.width - margin - 84, y: headerY - 48, width: 84, height: 48 })
        } catch {}
      }
      // Divider
      page.drawLine({ start: { x: margin, y: headerY - 16 }, end: { x: pageSize.width - margin, y: headerY - 16 }, thickness: 1, color: rgb(0.9,0.91,0.94) })

      // Grid 3x2 (6 per page)
      const cols = 2, rows = 3
      const gap = 12
      const cardW = (pageSize.width - margin*2 - gap*(cols-1))
      const colW = cardW / cols
      const cardH = 150
      const startY = headerY - 32 - 10

      for (let idx = 0; idx < cols*rows; idx++) {
        const p = prods[i + idx]
        if (!p) break
        const row = Math.floor(idx / cols)
        const col = idx % cols
        const x = margin + col * (colW + gap)
        const y = startY - row * (cardH + gap)

        // Card border
        page.drawRectangle({ x, y: y - cardH, width: colW, height: cardH, borderColor: rgb(0.9,0.91,0.94), borderWidth: 1, color: rgb(1,1,1) })
        // Image
        if (p.imageUrl) {
          try {
            const pth = join(process.cwd(), "public", p.imageUrl.replace(/^\//,''))
            const bytes = await readFile(pth)
            const ext = pth.split('.').pop()?.toLowerCase()
            let img
            if (ext === 'png') img = await pdf.embedPng(bytes)
            else img = await pdf.embedJpg(bytes)
            page.drawImage(img, { x: x + 8, y: y - 8 - 48, width: 48, height: 48 })
          } catch {}
        }
        // Text
        page.drawText(p.nameEn || '', { x: x+64, y: y - 16, size: 12, font, color: rgb(0.07,0.09,0.15) })
        page.drawText(p.scientificEn || '', { x: x+64, y: y - 32, size: 10, font, color: rgb(0.29,0.33,0.39) })
        page.drawText(`${p.pack} · ${p.price}`, { x: x+64, y: y - 48, size: 9, font, color: rgb(0.42,0.45,0.50) })
      }

      i += cols*rows
      if (i < prods.length) {
        continue // same company on next new page (loop adds page)
      } else {
        break
      }
    }
  }

  const pdfBytes = await pdf.save()
  const savePath = join(process.cwd(), "public", "catalogue.pdf")
  await writeFile(savePath, Buffer.from(pdfBytes))
  return new Response(Buffer.from(pdfBytes), { status: 200, headers: { "Content-Type": "application/pdf" } })
}
